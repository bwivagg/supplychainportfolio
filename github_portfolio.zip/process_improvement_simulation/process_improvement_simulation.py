#!/usr/bin/env python3
"""
Simulate order fulfillment wait times under two scenarios:
1. A single packaging station (baseline).
2. Two packaging stations working in parallel (improved).

This script generates synthetic order arrival and service times, runs the simulations,
computes summary statistics, and saves a bar chart comparing the average wait times.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def generate_orders(num_orders: int, seed: int = 42) -> pd.DataFrame:
    """Generate synthetic order arrival and processing times.

    Args:
        num_orders (int): Number of orders to simulate.
        seed (int): Random seed for reproducibility.

    Returns:
        pd.DataFrame: Orders with arrival_time and service_time columns.
    """
    rng = np.random.default_rng(seed)
    # Inter-arrival times drawn from an exponential distribution
    # A larger scale (mean) leads to less congestion; adjust to balance wait times.
    inter_arrivals = rng.exponential(scale=3.0, size=num_orders)
    arrival_times = np.cumsum(inter_arrivals)
    # Service times drawn from a log-normal distribution with mean around 2 minutes
    service_times = rng.lognormal(mean=np.log(2), sigma=0.3, size=num_orders)
    orders = pd.DataFrame({
        "arrival_time": arrival_times,
        "service_time": service_times,
    })
    return orders


def simulate_single_station(orders: pd.DataFrame) -> pd.DataFrame:
    """Simulate wait times for a single-station queue.

    Args:
        orders (pd.DataFrame): Input orders with arrival_time and service_time.

    Returns:
        pd.DataFrame: Orders with wait_time and finish_time columns.
    """
    wait_times = np.zeros(len(orders))
    finish_times = np.zeros(len(orders))
    current_finish = 0.0
    for i, row in orders.iterrows():
        arrival, service = row["arrival_time"], row["service_time"]
        start_time = max(arrival, current_finish)
        wait_times[i] = start_time - arrival
        finish_times[i] = start_time + service
        current_finish = finish_times[i]
    result = orders.copy()
    result["wait_time"] = wait_times
    result["finish_time"] = finish_times
    return result


def simulate_two_station(orders: pd.DataFrame) -> pd.DataFrame:
    """Simulate wait times for a two-station queue (parallel servers).

    Args:
        orders (pd.DataFrame): Input orders with arrival_time and service_time.

    Returns:
        pd.DataFrame: Orders with wait_time and finish_time columns.
    """
    wait_times = np.zeros(len(orders))
    finish_times = np.zeros(len(orders))
    # Maintain finish times for both stations
    station_finish_times = [0.0, 0.0]
    for i, row in orders.iterrows():
        arrival, service = row["arrival_time"], row["service_time"]
        # Determine which station will be free first
        next_station = int(np.argmin(station_finish_times))
        # Start time is max(arrival, finish of chosen station)
        start_time = max(arrival, station_finish_times[next_station])
        wait_times[i] = start_time - arrival
        finish_times[i] = start_time + service
        station_finish_times[next_station] = finish_times[i]
    result = orders.copy()
    result["wait_time"] = wait_times
    result["finish_time"] = finish_times
    return result


def main():
    # Generate synthetic order data
    orders = generate_orders(num_orders=500)
    # Simulate both scenarios
    single = simulate_single_station(orders)
    dual = simulate_two_station(orders)
    # Compute average wait time
    avg_wait_single = single["wait_time"].mean()
    avg_wait_dual = dual["wait_time"].mean()
    print(f"Average wait time (single station): {avg_wait_single:.2f} minutes")
    print(f"Average wait time (two stations): {avg_wait_dual:.2f} minutes")
    # Create results directory
    import os
    results_dir = os.path.join(os.path.dirname(__file__), "results")
    os.makedirs(results_dir, exist_ok=True)
    # Plot comparison
    labels = ["Single Station", "Two Stations"]
    avg_waits = [avg_wait_single, avg_wait_dual]
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(labels, avg_waits)
    ax.set_ylabel("Average Wait Time (minutes)")
    ax.set_title("Order Fulfillment Wait Time Comparison")
    for i, v in enumerate(avg_waits):
        ax.text(i, v + 0.05, f"{v:.2f}", ha='center', va='bottom')
    plt.tight_layout()
    output_path = os.path.join(results_dir, "wait_time_comparison.png")
    fig.savefig(output_path)
    plt.close(fig)
    # Save summary as CSV for completeness
    summary = pd.DataFrame({
        "scenario": labels,
        "average_wait_time": avg_waits
    })
    summary.to_csv(os.path.join(results_dir, "summary.csv"), index=False)


if __name__ == "__main__":
    main()