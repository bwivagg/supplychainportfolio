# Supply Chain Demand Analysis

This project performs an exploratory analysis on a synthetic retail demand data set. The goal is to demonstrate how data analytics can reveal patterns in sales, identify under‑ and over‑performing SKUs, and inform inventory planning decisions. The analysis looks at demand seasonality, weekly averages, and service level metrics.

## Data

The synthetic data set (`demand_data.csv`) contains six months of weekly demand for ten unique SKUs. Each record includes:

- `week`: Week number (1–26)
- `sku`: Product identifier (`SKU1` – `SKU10`)
- `demand_units`: Number of units sold in that week
- `inventory_on_hand`: Simulated inventory available at the start of each week
- `inventory_after`: Inventory remaining after fulfilling demand

The script calculates service level as the proportion of demand fulfilled (inventory_on_hand vs. demand).

## How to Run

1. Install dependencies (if not already available):

   ```bash
   pip install pandas matplotlib
   ```

2. Execute the analysis script from the project directory:

   ```bash
   python supply_chain_analysis.py
   ```

   The script will read the CSV, produce summary statistics, and save charts and a summary report in the `results/` folder.

3. Review the generated figures in the `results/` folder, such as demand patterns for top SKUs and service level by week.

## Key Skills Demonstrated

- **Data Wrangling**: Uses Pandas to manipulate and aggregate time‑series data.
- **Visualization**: Employs Matplotlib to highlight seasonality and SKU performance.
- **Inventory Analysis**: Calculates service levels and identifies potential stockouts.

## Files

- `supply_chain_analysis.py` – Main script that runs the analysis.
- `demand_data.csv` – Synthetic weekly demand data for 10 SKUs.
- `results/` – Folder where output charts and summary files are saved after running the analysis.
