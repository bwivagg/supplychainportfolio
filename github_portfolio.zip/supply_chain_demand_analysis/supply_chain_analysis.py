#!/usr/bin/env python3
"""
Perform exploratory demand and service level analysis on a synthetic retail data set.
Generates summary statistics and visualizations highlighting demand patterns and inventory performance.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os


def load_data(filepath: str) -> pd.DataFrame:
    """Load demand data from CSV."""
    return pd.read_csv(filepath)


def generate_synthetic_data(num_weeks: int = 26, num_skus: int = 10, seed: int = 123) -> pd.DataFrame:
    """Generate a synthetic data set for demonstration purposes.

    Args:
        num_weeks (int): Number of weeks to simulate.
        num_skus (int): Number of unique SKUs.
        seed (int): Random seed for reproducibility.

    Returns:
        pd.DataFrame: Synthetic weekly demand and inventory data.
    """
    rng = np.random.default_rng(seed)
    skus = [f"SKU{i+1}" for i in range(num_skus)]
    data = []
    for week in range(1, num_weeks + 1):
        # Seasonality factor: simulate rising demand mid‑season
        season_factor = 1 + 0.5 * np.sin((week / num_weeks) * 2 * np.pi)
        for sku in skus:
            base_demand = rng.integers(50, 200)  # base range of demand
            demand_units = int(base_demand * season_factor * rng.uniform(0.8, 1.2))
            inventory_on_hand = rng.integers(demand_units, demand_units + 50)
            inventory_after = max(inventory_on_hand - demand_units, 0)
            data.append({
                "week": week,
                "sku": sku,
                "demand_units": demand_units,
                "inventory_on_hand": inventory_on_hand,
                "inventory_after": inventory_after,
            })
    return pd.DataFrame(data)


def analyze_data(df: pd.DataFrame, results_dir: str) -> None:
    """Compute summary statistics and generate charts."""
    # Compute total demand by week
    demand_by_week = df.groupby("week")["demand_units"].sum().reset_index()
    # Compute total demand by SKU
    demand_by_sku = df.groupby("sku")["demand_units"].sum().reset_index()
    top3_skus = demand_by_sku.nlargest(3, "demand_units")["sku"].tolist()
    # Service level: fulfilled demand / total demand
    df["fulfilled_units"] = np.minimum(df["demand_units"], df["inventory_on_hand"])
    df["service_level"] = df["fulfilled_units"] / df["demand_units"]
    service_by_week = df.groupby("week")["service_level"].mean().reset_index()
    # Plot total demand by week
    fig1, ax1 = plt.subplots(figsize=(7, 4))
    ax1.plot(demand_by_week["week"], demand_by_week["demand_units"], marker="o")
    ax1.set_xlabel("Week")
    ax1.set_ylabel("Total Demand Units")
    ax1.set_title("Weekly Total Demand Across All SKUs")
    fig1.tight_layout()
    fig1.savefig(os.path.join(results_dir, "weekly_total_demand.png"))
    plt.close(fig1)
    # Plot demand patterns for top 3 SKUs
    fig2, ax2 = plt.subplots(figsize=(7, 4))
    for sku in top3_skus:
        sku_df = df[df["sku"] == sku]
        sku_weekly = sku_df.groupby("week")["demand_units"].sum().reset_index()
        ax2.plot(sku_weekly["week"], sku_weekly["demand_units"], marker="o", label=sku)
    ax2.set_xlabel("Week")
    ax2.set_ylabel("Demand Units")
    ax2.set_title("Demand Trends for Top 3 SKUs")
    ax2.legend()
    fig2.tight_layout()
    fig2.savefig(os.path.join(results_dir, "top3_sku_trends.png"))
    plt.close(fig2)
    # Plot service level by week
    fig3, ax3 = plt.subplots(figsize=(7, 4))
    ax3.plot(service_by_week["week"], service_by_week["service_level"], marker="o")
    ax3.set_xlabel("Week")
    ax3.set_ylabel("Average Service Level")
    ax3.set_title("Weekly Service Level (Fulfillment Rate)")
    ax3.set_ylim(0, 1.05)
    fig3.tight_layout()
    fig3.savefig(os.path.join(results_dir, "weekly_service_level.png"))
    plt.close(fig3)
    # Save summary table
    summary_df = demand_by_sku.sort_values("demand_units", ascending=False)
    summary_df.to_csv(os.path.join(results_dir, "sku_demand_summary.csv"), index=False)
    service_by_week.to_csv(os.path.join(results_dir, "service_level_by_week.csv"), index=False)


def main():
    # Determine file paths
    current_dir = os.path.dirname(__file__)
    data_path = os.path.join(current_dir, "demand_data.csv")
    results_dir = os.path.join(current_dir, "results")
    os.makedirs(results_dir, exist_ok=True)
    # If the data file does not exist, generate and save it
    if not os.path.exists(data_path):
        synthetic_df = generate_synthetic_data()
        synthetic_df.to_csv(data_path, index=False)
        print(f"Generated synthetic data at {data_path}")
    # Load data
    df = load_data(data_path)
    # Analyze and visualize
    analyze_data(df, results_dir)
    print("Analysis complete. Results saved in 'results' directory.")


if __name__ == "__main__":
    main()