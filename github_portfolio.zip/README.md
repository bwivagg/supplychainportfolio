# Ben Wivagg – Data & Operations Portfolio

## Executive Summary

This portfolio showcases a set of projects that demonstrate my ability to improve processes, analyze complex data sets, and tell compelling business stories through metrics and visualizations. Each project targets a core competency needed for Program Management, Business/Data Analysis, and Supply Chain Management roles. The work illustrates how I use tools such as Python, SQL, and visualization libraries to deliver actionable insights, optimize operations, and drive engagement.

### Projects Overview

1. **Process Improvement Simulation** – A discrete‑event simulation of a warehouse order fulfillment process, complete with before and after scenarios. It highlights how simple changes in batching and scheduling can reduce average order wait time and improve throughput. The analysis includes code, synthetic data generation, and charts to visualize improvements.
2. **Supply Chain Demand Analysis** – An exploratory data analysis on a synthetic six‑month retail demand data set. The project uses Python (Pandas, matplotlib) to assess seasonality, product performance, and service level attainment. It delivers dashboards and recommendations to improve inventory positioning and forecast accuracy.
3. **Engagement & Operations Metrics Dashboard** – A lightweight dashboard built with Python and Plotly Dash (exported as HTML) that reads transaction log data and calculates key engagement metrics, such as conversion rates, customer retention, and order cycle times. The dashboard demonstrates my ability to design metrics, derive insights from user behavior, and communicate results in a clear, interactive format.

Each project folder includes its own README with instructions, the code needed to run it, and a summary of findings. To get started with any project, follow the instructions in the relevant folder.

## How to Use This Portfolio

1. Clone or download this repository.
2. Navigate into any project folder and open its README for instructions.
3. To reproduce results, ensure you have Python 3.10+ and install dependencies listed in the project requirements (typically via `pip install -r requirements.txt`).
4. Run the provided scripts or notebooks, and review the generated outputs (charts, tables, and summaries).

### Contact

If you have questions or would like to discuss any of these projects, feel free to reach out via LinkedIn or email. I’m always excited to collaborate and drive operational excellence through data‑driven decision making.