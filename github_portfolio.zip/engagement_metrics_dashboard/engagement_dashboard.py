#!/usr/bin/env python3
"""
Analyze synthetic user engagement data and generate key metrics and charts.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
from datetime import datetime, timedelta


def generate_log_data(num_sessions: int = 5000, seed: int = 123) -> pd.DataFrame:
    """Generate synthetic user session log data.

    Args:
        num_sessions (int): Number of user sessions to simulate.
        seed (int): Random seed for reproducibility.

    Returns:
        pd.DataFrame: Synthetic log data with columns (session_id, user_id, timestamp, action).
    """
    rng = np.random.default_rng(seed)
    log_records = []
    start_date = datetime(2025, 1, 1)
    # user IDs: assume 1000 unique users
    user_ids = [f"U{str(i).zfill(4)}" for i in range(1000)]
    session_counter = 0
    for _ in range(num_sessions):
        session_id = f"S{session_counter:06d}"
        user_id = rng.choice(user_ids)
        # session start time random within the month
        session_start = start_date + timedelta(days=float(rng.integers(0, 30))) + timedelta(minutes=float(rng.integers(0, 24*60)))
        # number of events in session
        num_events = rng.integers(3, 8)
        # event times in minutes from start (sorted)
        event_times = sorted(rng.integers(0, 30, size=num_events))
        # assign actions: first action always 'view', last may be 'purchase' depending on probability
        actions = []
        for i in range(num_events):
            if i == 0:
                actions.append('view')
            else:
                # weighted actions: add_to_cart more likely mid‑session; purchase only toward end
                if i == num_events - 1 and rng.random() < 0.3:
                    actions.append('purchase')
                else:
                    actions.append(rng.choice(['view', 'add_to_cart'], p=[0.6, 0.4]))
        for t_offset, act in zip(event_times, actions):
            timestamp = session_start + timedelta(minutes=float(t_offset))
            log_records.append({
                'session_id': session_id,
                'user_id': user_id,
                'timestamp': timestamp,
                'action': act
            })
        session_counter += 1
    df = pd.DataFrame(log_records)
    return df


def analyze_log_data(df: pd.DataFrame, results_dir: str) -> None:
    """Compute metrics and generate charts from log data."""
    # Ensure timestamp is datetime
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    # Compute session level summary
    session_groups = df.groupby('session_id')
    session_summary = session_groups.agg(
        user_id=('user_id', 'first'),
        start_time=('timestamp', 'min'),
        end_time=('timestamp', 'max'),
        num_events=('action', 'count'),
        has_purchase=('action', lambda x: 'purchase' in x.values),
    ).reset_index()
    session_summary['session_length_minutes'] = (session_summary['end_time'] - session_summary['start_time']).dt.total_seconds() / 60.0
    # Conversion rate
    conversion_rate = session_summary['has_purchase'].mean()
    # Average session length
    avg_session_length = session_summary['session_length_minutes'].mean()
    print(f"Conversion rate: {conversion_rate:.2%}")
    print(f"Average session length: {avg_session_length:.1f} minutes")
    # Retention: compute user visits by week
    df['week'] = df['timestamp'].dt.isocalendar().week
    user_week = df.groupby(['user_id', 'week']).size().reset_index(name='events')
    # Define retention from first to second week: fraction of users present in week 1 that return in week 2
    week_numbers = sorted(user_week['week'].unique())
    if len(week_numbers) >= 2:
        week1_users = set(user_week[user_week['week'] == week_numbers[0]]['user_id'])
        week2_users = set(user_week[user_week['week'] == week_numbers[1]]['user_id'])
        retention_rate = len(week1_users & week2_users) / len(week1_users)
    else:
        retention_rate = float('nan')
    print(f"Week 1->2 user retention: {retention_rate:.2%}")
    # Plot session length distribution
    fig1, ax1 = plt.subplots(figsize=(6, 4))
    ax1.hist(session_summary['session_length_minutes'], bins=30, edgecolor='black')
    ax1.set_xlabel("Session Length (minutes)")
    ax1.set_ylabel("Number of Sessions")
    ax1.set_title("Distribution of Session Lengths")
    fig1.tight_layout()
    fig1.savefig(os.path.join(results_dir, "session_length_distribution.png"))
    plt.close(fig1)
    # Plot conversion rate vs. non‑conversion
    fig2, ax2 = plt.subplots(figsize=(5, 4))
    conv_counts = session_summary['has_purchase'].value_counts().reindex([True, False], fill_value=0)
    ax2.bar(['Converted', 'Not Converted'], conv_counts.values)
    ax2.set_ylabel("Number of Sessions")
    ax2.set_title("Sessions With and Without Purchase")
    fig2.tight_layout()
    fig2.savefig(os.path.join(results_dir, "conversion_rate_bar.png"))
    plt.close(fig2)
    # Plot retention from week1->week2 if computed
    if not np.isnan(retention_rate):
        fig3, ax3 = plt.subplots(figsize=(5, 4))
        ax3.bar(['Retained', 'Not Retained'], [len(week1_users & week2_users), len(week1_users - week2_users)])
        ax3.set_ylabel("Number of Users")
        ax3.set_title("User Retention from Week 1 to Week 2")
        fig3.tight_layout()
        fig3.savefig(os.path.join(results_dir, "retention_week1_to_week2.png"))
        plt.close(fig3)
    # Save session summary to CSV
    session_summary.to_csv(os.path.join(results_dir, "session_summary.csv"), index=False)
    # Save high level metrics as text
    with open(os.path.join(results_dir, "metrics_summary.txt"), 'w') as f:
        f.write(f"Conversion rate: {conversion_rate:.2%}\n")
        f.write(f"Average session length (min): {avg_session_length:.1f}\n")
        f.write(f"Week1->2 retention: {retention_rate:.2%}\n")


def main():
    current_dir = os.path.dirname(__file__)
    data_path = os.path.join(current_dir, "log_data.csv")
    results_dir = os.path.join(current_dir, "results")
    os.makedirs(results_dir, exist_ok=True)
    # Generate data if not exists
    if not os.path.exists(data_path):
        log_df = generate_log_data()
        log_df.to_csv(data_path, index=False)
        print(f"Generated synthetic log data at {data_path}")
    # Load data
    df = pd.read_csv(data_path)
    # Analyze
    analyze_log_data(df, results_dir)
    print("Engagement analysis complete. See 'results' directory for outputs.")


if __name__ == "__main__":
    main()