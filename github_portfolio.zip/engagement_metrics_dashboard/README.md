# Engagement & Operations Metrics Dashboard

This project analyzes synthetic user session data to create a set of key engagement and operational metrics. While the included script currently produces static charts and summary tables for reproducibility, it also serves as a blueprint for building an interactive dashboard using Plotly Dash or another BI tool.

## Data

The synthetic data (`log_data.csv`) includes 5,000 simulated user sessions over a one‑month period. Each record contains:

- `session_id` – unique identifier for a session
- `user_id` – identifier for the user
- `timestamp` – event time
- `action` – type of user action (`view`, `add_to_cart`, `purchase`)

From this data the script derives metrics such as:

- **Conversion rate**: percentage of sessions that include a purchase
- **Average session length**: estimated using differences between the first and last events in a session
- **User retention**: proportion of users returning to the site across weeks

## How to Run

1. Install dependencies (if not already available):

   ```bash
   pip install pandas matplotlib
   ```

2. Execute the analysis script from the project directory:

   ```bash
   python engagement_dashboard.py
   ```

   The script will read the CSV, compute metrics, and save visualizations and summary tables to the `results/` folder.

3. Open the generated charts (`results/`) to explore the engagement patterns. If you wish to extend this into an interactive dashboard, you can use the metrics calculated in the script with Plotly Dash or another framework.

## Key Skills Demonstrated

- **Engagement Analytics**: Calculates conversion rates, session durations, and user retention metrics.
- **Data Visualization**: Uses Matplotlib to visualize user journeys and retention curves.
- **Communication of Insights**: Presents findings in a way that can inform product management and operational decisions.

## Files

- `engagement_dashboard.py` – Script that processes the synthetic log data, computes metrics, and produces charts.
- `log_data.csv` – Synthetic user session log data.
- `results/` – Folder where output charts and summary tables are saved after running the script.
